package com.example.myimageapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView

class MainActivity : AppCompatActivity(), View.OnClickListener  {
    private var i: Int = 0
    private lateinit var img: ImageView
    private lateinit var tombol: Button

    override fun onClick(v: View) {
        if (v.id == R.id.tombolklik){
            img = findViewById(R.id.img)
            if (i==1){
                i=2
                img.setImageResource(R.drawable.car2)
            }else{
                i=1
                img.setImageResource(R.drawable.car1)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        i=1
        tombol = findViewById(R.id.tombolklik)
        tombol.setOnClickListener(this)
    }
}
